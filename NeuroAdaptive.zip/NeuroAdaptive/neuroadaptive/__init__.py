"Neuroadaptive real-time brain-AI loop package."
